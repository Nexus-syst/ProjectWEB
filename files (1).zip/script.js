document.getElementById('greetForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const nameInput = document.getElementById('name');
    const messageDiv = document.getElementById('message');
    const name = nameInput.value.trim();

    fetch('greet.php', {
        method: 'POST',
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: "name=" + encodeURIComponent(name)
    })
    .then(response => response.json())
    .then(data => {
        messageDiv.textContent = data.message;
    })
    .catch(() => {
        messageDiv.textContent = "Your request was unsuccessful.";
    });
});